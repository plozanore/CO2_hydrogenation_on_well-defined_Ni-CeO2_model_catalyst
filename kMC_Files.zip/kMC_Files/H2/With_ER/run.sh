#!/bin/bash
for i in CO2_13_5_H2_25_3_seed_1 CO2_13_5_H2_25_3_seed_2 CO2_13_5_H2_25_3_seed_3 CO2_13_5_H2_25_3_seed_4 CO2_13_5_H2_25_3_seed_5 CO2_13_5_H2_30_36_seed_1 CO2_13_5_H2_30_36_seed_2 CO2_13_5_H2_30_36_seed_3 CO2_13_5_H2_30_36_seed_4 CO2_13_5_H2_30_36_seed_5 CO2_13_5_H2_35_43_seed_1 CO2_13_5_H2_35_43_seed_2 CO2_13_5_H2_35_43_seed_3 CO2_13_5_H2_35_43_seed_4 CO2_13_5_H2_35_43_seed_5 CO2_13_5_H2_40_5_seed_1 CO2_13_5_H2_40_5_seed_2 CO2_13_5_H2_40_5_seed_3 CO2_13_5_H2_40_5_seed_4 CO2_13_5_H2_40_5_seed_5
do 
    cd $i 
    cp ../zac_submit . 
    qsub -N $i zac_submit 
    cd .. 
done
